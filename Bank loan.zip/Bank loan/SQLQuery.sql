/* =====================================================================
   BANK LOAN ANALYSIS - SQL QUERIES (SQL Server)
   Author  : Tanupriya (github.com/Tanu-3018)
   Table   : bank_loan_data
   Good Loan      = loan_status is 'Fully Paid' or 'Current'
   Bad Loan       = loan_status is 'Charged Off'
   Current month  = the latest month in the data (December)
   Previous month = the month before the latest month (November)

  
   ===================================================================== */


/* =====================================================================
   PART 0: LOAD AND CLEAN THE DATA
   Step 1: In SQL Server Management Studio, right click the database,
           choose Tasks > Import Flat File, and load financial_loan.csv
           as a table named bank_loan_data.
   Step 2: Run the cleaning steps below.
   ===================================================================== */

-- 0.1 Check the number of records (expected: 38576)
SELECT COUNT(*) AS Total_Records
FROM bank_loan_data;

-- 0.2 Check for duplicate loan IDs (expected: 0 rows)
SELECT id, COUNT(*) AS Times_Repeated
FROM bank_loan_data
GROUP BY id
HAVING COUNT(*) > 1;

-- 0.3 Check for missing values in important columns (expected: all 0)
SELECT
    SUM(CASE WHEN loan_amount   IS NULL THEN 1 ELSE 0 END) AS Missing_Loan_Amount,
    SUM(CASE WHEN total_payment IS NULL THEN 1 ELSE 0 END) AS Missing_Total_Payment,
    SUM(CASE WHEN loan_status   IS NULL THEN 1 ELSE 0 END) AS Missing_Loan_Status,
    SUM(CASE WHEN issue_date    IS NULL THEN 1 ELSE 0 END) AS Missing_Issue_Date
FROM bank_loan_data;

-- 0.4 Check the loan status values (expected: Fully Paid, Charged Off, Current)
SELECT loan_status, COUNT(id) AS Loan_Count
FROM bank_loan_data
GROUP BY loan_status;

-- 0.5 Remove extra spaces from the term column
--     (in the file, the term is written as ' 36 months' with a space in front)
UPDATE bank_loan_data
SET term = LTRIM(RTRIM(term));

-- 0.6 Change the issue date to a real date type.
--     In the file, dates are written as day-month-year (for example 11-02-2021).
--     Skip this step if SQL Server already shows issue_date as a date column.
SET DATEFORMAT dmy;
ALTER TABLE bank_loan_data ALTER COLUMN issue_date DATE;

-- 0.7 Check the date range (expected: 2021-01-01 to 2021-12-12)
SELECT MIN(issue_date) AS First_Date, MAX(issue_date) AS Last_Date
FROM bank_loan_data;


/* =====================================================================
   PART 1: SUMMARY - MAIN NUMBERS (KEY PERFORMANCE INDICATORS)
   ===================================================================== */

-- 1.1 Total Loan Applications (all months: 38576)
SELECT COUNT(id) AS Total_Applications
FROM bank_loan_data;

-- Current month (December: 4314)
SELECT COUNT(id) AS Current_Month_Total_Applications
FROM bank_loan_data
WHERE MONTH(issue_date) = 12;

-- Previous month (November: 4035)
SELECT COUNT(id) AS Previous_Month_Total_Applications
FROM bank_loan_data
WHERE MONTH(issue_date) = 11;


-- 1.2 Total Funded Amount (all months: 435757075)
SELECT SUM(loan_amount) AS Total_Funded_Amount
FROM bank_loan_data;

-- Current month (53981425)
SELECT SUM(loan_amount) AS Current_Month_Total_Funded_Amount
FROM bank_loan_data
WHERE MONTH(issue_date) = 12;

-- Previous month (47754825)
SELECT SUM(loan_amount) AS Previous_Month_Total_Funded_Amount
FROM bank_loan_data
WHERE MONTH(issue_date) = 11;


-- 1.3 Total Amount Received (all months: 473070933)
SELECT SUM(total_payment) AS Total_Amount_Received
FROM bank_loan_data;

-- Current month (58074380)
SELECT SUM(total_payment) AS Current_Month_Total_Amount_Received
FROM bank_loan_data
WHERE MONTH(issue_date) = 12;

-- Previous month (50132030)
SELECT SUM(total_payment) AS Previous_Month_Total_Amount_Received
FROM bank_loan_data
WHERE MONTH(issue_date) = 11;


-- 1.4 Average Interest Rate in percent (all months: about 12.05)
SELECT ROUND(AVG(int_rate) * 100, 2) AS Avg_Interest_Rate
FROM bank_loan_data;

-- Current month (about 12.36)
SELECT ROUND(AVG(int_rate) * 100, 2) AS Current_Month_Avg_Interest_Rate
FROM bank_loan_data
WHERE MONTH(issue_date) = 12;

-- Previous month (about 11.94)
SELECT ROUND(AVG(int_rate) * 100, 2) AS Previous_Month_Avg_Interest_Rate
FROM bank_loan_data
WHERE MONTH(issue_date) = 11;


-- 1.5 Average Debt-to-Income ratio in percent (all months: about 13.33)
SELECT ROUND(AVG(dti) * 100, 2) AS Avg_Debt_To_Income_Ratio
FROM bank_loan_data;

-- Current month (about 13.67)
SELECT ROUND(AVG(dti) * 100, 2) AS Current_Month_Avg_Debt_To_Income_Ratio
FROM bank_loan_data
WHERE MONTH(issue_date) = 12;

-- Previous month (about 13.30)
SELECT ROUND(AVG(dti) * 100, 2) AS Previous_Month_Avg_Debt_To_Income_Ratio
FROM bank_loan_data
WHERE MONTH(issue_date) = 11;


/* =====================================================================
   PART 2: GOOD LOANS
   ===================================================================== */

-- 2.1 Good Loan Percentage (about 86.18)
SELECT
    ROUND(
        COUNT(CASE WHEN loan_status IN ('Fully Paid', 'Current') THEN id END) * 100.0
        / COUNT(id), 2) AS Good_Loan_Percentage
FROM bank_loan_data;

-- 2.2 Good Loan Applications (33243)
SELECT COUNT(id) AS Good_Loan_Applications
FROM bank_loan_data
WHERE loan_status IN ('Fully Paid', 'Current');

-- 2.3 Good Loan Funded Amount (370224850)
SELECT SUM(loan_amount) AS Good_Loan_Funded_Amount
FROM bank_loan_data
WHERE loan_status IN ('Fully Paid', 'Current');

-- 2.4 Good Loan Amount Received (435786170)
SELECT SUM(total_payment) AS Good_Loan_Amount_Received
FROM bank_loan_data
WHERE loan_status IN ('Fully Paid', 'Current');


/* =====================================================================
   PART 3: BAD LOANS
   ===================================================================== */

-- 3.1 Bad Loan Percentage (about 13.82)
SELECT
    ROUND(
        COUNT(CASE WHEN loan_status = 'Charged Off' THEN id END) * 100.0
        / COUNT(id), 2) AS Bad_Loan_Percentage
FROM bank_loan_data;

-- 3.2 Bad Loan Applications (5333)
SELECT COUNT(id) AS Bad_Loan_Applications
FROM bank_loan_data
WHERE loan_status = 'Charged Off';

-- 3.3 Bad Loan Funded Amount (65532225)
SELECT SUM(loan_amount) AS Bad_Loan_Funded_Amount
FROM bank_loan_data
WHERE loan_status = 'Charged Off';

-- 3.4 Bad Loan Amount Received (37284763)
SELECT SUM(total_payment) AS Bad_Loan_Amount_Received
FROM bank_loan_data
WHERE loan_status = 'Charged Off';


/* =====================================================================
   PART 4: LOAN STATUS GRID
   ===================================================================== */

-- 4.1 All months
SELECT
    loan_status,
    COUNT(id)                      AS Loan_Count,
    SUM(total_payment)             AS Total_Amount_Received,
    SUM(loan_amount)               AS Total_Funded_Amount,
    ROUND(AVG(int_rate * 100), 2)  AS Interest_Rate,
    ROUND(AVG(dti * 100), 2)       AS Debt_To_Income_Ratio
FROM bank_loan_data
GROUP BY loan_status;

-- 4.2 Current month only
SELECT
    loan_status,
    SUM(total_payment) AS Current_Month_Total_Amount_Received,
    SUM(loan_amount)   AS Current_Month_Total_Funded_Amount
FROM bank_loan_data
WHERE MONTH(issue_date) = 12
GROUP BY loan_status;


/* =====================================================================
   PART 5: OVERVIEW - BREAKDOWNS
   ===================================================================== */

-- 5.1 By Month
SELECT
    MONTH(issue_date)           AS Month_Number,
    DATENAME(MONTH, issue_date) AS Month_Name,
    COUNT(id)                   AS Total_Loan_Applications,
    SUM(loan_amount)            AS Total_Funded_Amount,
    SUM(total_payment)          AS Total_Amount_Received
FROM bank_loan_data
GROUP BY MONTH(issue_date), DATENAME(MONTH, issue_date)
ORDER BY MONTH(issue_date);

-- 5.2 By State
SELECT
    address_state      AS State,
    COUNT(id)          AS Total_Loan_Applications,
    SUM(loan_amount)   AS Total_Funded_Amount,
    SUM(total_payment) AS Total_Amount_Received
FROM bank_loan_data
GROUP BY address_state
ORDER BY SUM(loan_amount) DESC;

-- 5.3 By Term
SELECT
    term               AS Term,
    COUNT(id)          AS Total_Loan_Applications,
    SUM(loan_amount)   AS Total_Funded_Amount,
    SUM(total_payment) AS Total_Amount_Received
FROM bank_loan_data
GROUP BY term
ORDER BY term;

-- 5.4 By Employee Length
SELECT
    emp_length         AS Employee_Length,
    COUNT(id)          AS Total_Loan_Applications,
    SUM(loan_amount)   AS Total_Funded_Amount,
    SUM(total_payment) AS Total_Amount_Received
FROM bank_loan_data
GROUP BY emp_length
ORDER BY COUNT(id) DESC;

-- 5.5 By Purpose
SELECT
    purpose            AS Purpose,
    COUNT(id)          AS Total_Loan_Applications,
    SUM(loan_amount)   AS Total_Funded_Amount,
    SUM(total_payment) AS Total_Amount_Received
FROM bank_loan_data
GROUP BY purpose
ORDER BY COUNT(id) DESC;

-- 5.6 By Home Ownership
SELECT
    home_ownership     AS Home_Ownership,
    COUNT(id)          AS Total_Loan_Applications,
    SUM(loan_amount)   AS Total_Funded_Amount,
    SUM(total_payment) AS Total_Amount_Received
FROM bank_loan_data
GROUP BY home_ownership
ORDER BY COUNT(id) DESC;


/* =====================================================================
   PART 6: FILTER EXAMPLE
   The dashboard has filters. To see the same result in SQL, add a WHERE
   condition. Example: only Grade A loans, grouped by purpose.
   ===================================================================== */
SELECT
    purpose            AS Purpose,
    COUNT(id)          AS Total_Loan_Applications,
    SUM(loan_amount)   AS Total_Funded_Amount,
    SUM(total_payment) AS Total_Amount_Received
FROM bank_loan_data
WHERE grade = 'A'
GROUP BY purpose
ORDER BY purpose;


/* =====================================================================
   PART 7: MY OWN RISK ANALYSIS
   Question: which type of loan goes bad most often?
   Bad Loan Percentage = Charged Off loans / all loans in that group x 100
   ===================================================================== */

-- 7.1 Bad loan percentage by grade (Grade A is lowest, Grade G is highest)
SELECT
    grade,
    COUNT(id) AS Total_Loans,
    COUNT(CASE WHEN loan_status = 'Charged Off' THEN id END) AS Bad_Loans,
    ROUND(COUNT(CASE WHEN loan_status = 'Charged Off' THEN id END) * 100.0
          / COUNT(id), 2) AS Bad_Loan_Percentage
FROM bank_loan_data
GROUP BY grade
ORDER BY grade;

-- 7.2 Bad loan percentage by term (36 months about 10.71, 60 months about 22.34)
SELECT
    term,
    COUNT(id) AS Total_Loans,
    COUNT(CASE WHEN loan_status = 'Charged Off' THEN id END) AS Bad_Loans,
    ROUND(COUNT(CASE WHEN loan_status = 'Charged Off' THEN id END) * 100.0
          / COUNT(id), 2) AS Bad_Loan_Percentage
FROM bank_loan_data
GROUP BY term
ORDER BY term;

-- 7.3 Bad loan percentage by purpose (small business is the highest)
SELECT
    purpose,
    COUNT(id) AS Total_Loans,
    COUNT(CASE WHEN loan_status = 'Charged Off' THEN id END) AS Bad_Loans,
    ROUND(COUNT(CASE WHEN loan_status = 'Charged Off' THEN id END) * 100.0
          / COUNT(id), 2) AS Bad_Loan_Percentage
FROM bank_loan_data
GROUP BY purpose
ORDER BY Bad_Loan_Percentage DESC;

-- 7.4 Bad loan percentage by home ownership
SELECT
    home_ownership,
    COUNT(id) AS Total_Loans,
    COUNT(CASE WHEN loan_status = 'Charged Off' THEN id END) AS Bad_Loans,
    ROUND(COUNT(CASE WHEN loan_status = 'Charged Off' THEN id END) * 100.0
          / COUNT(id), 2) AS Bad_Loan_Percentage
FROM bank_loan_data
GROUP BY home_ownership
ORDER BY Bad_Loan_Percentage DESC;

-- 7.5 Bad loan percentage by income verification status
SELECT
    verification_status,
    COUNT(id) AS Total_Loans,
    COUNT(CASE WHEN loan_status = 'Charged Off' THEN id END) AS Bad_Loans,
    ROUND(COUNT(CASE WHEN loan_status = 'Charged Off' THEN id END) * 100.0
          / COUNT(id), 2) AS Bad_Loan_Percentage
FROM bank_loan_data
GROUP BY verification_status
ORDER BY Bad_Loan_Percentage DESC;

-- 7.6 Bad loan percentage by Debt-to-Income ratio band
SELECT
    CASE
        WHEN dti * 100 < 10 THEN '1. Below 10 percent'
        WHEN dti * 100 < 20 THEN '2. 10 to 20 percent'
        ELSE                     '3. 20 percent and above'
    END AS Debt_To_Income_Band,
    COUNT(id) AS Total_Loans,
    COUNT(CASE WHEN loan_status = 'Charged Off' THEN id END) AS Bad_Loans,
    ROUND(COUNT(CASE WHEN loan_status = 'Charged Off' THEN id END) * 100.0
          / COUNT(id), 2) AS Bad_Loan_Percentage
FROM bank_loan_data
GROUP BY
    CASE
        WHEN dti * 100 < 10 THEN '1. Below 10 percent'
        WHEN dti * 100 < 20 THEN '2. 10 to 20 percent'
        ELSE                     '3. 20 percent and above'
    END
ORDER BY Debt_To_Income_Band;

-- 7.7 Money lost on bad loans
--     Funded 65532225, received 37284763, shortfall 28247462 (about 56.9 percent recovered)
SELECT
    SUM(loan_amount)                                    AS Bad_Loan_Funded_Amount,
    SUM(total_payment)                                  AS Bad_Loan_Amount_Received,
    SUM(loan_amount) - SUM(total_payment)               AS Money_Not_Recovered,
    ROUND(SUM(total_payment) * 100.0 / SUM(loan_amount), 2) AS Percentage_Recovered
FROM bank_loan_data
WHERE loan_status = 'Charged Off';